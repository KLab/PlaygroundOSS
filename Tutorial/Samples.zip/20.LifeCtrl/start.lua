function setup()
end

function execute(deltaT)
	sysLoad("asset://LifeCtrl.lua")
end

function leave()

end
