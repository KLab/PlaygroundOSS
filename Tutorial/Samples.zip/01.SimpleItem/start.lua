function setup()
end

function execute(deltaT)
	sysLoad("asset://SimpleItem.lua")
end

function leave()

end
