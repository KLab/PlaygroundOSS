function setup()
end

function execute(deltaT)
	sysLoad("asset://PieChart.lua")
end

function leave()

end
