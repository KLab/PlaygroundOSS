function setup()
end

function execute(deltaT)
	sysLoad("asset://RubberBand.lua")
end

function leave()

end
