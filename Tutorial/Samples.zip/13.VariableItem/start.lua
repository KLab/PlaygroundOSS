function setup()
end

function execute(deltaT)
	sysLoad("asset://VariableItem.lua")
end

function leave()

end
