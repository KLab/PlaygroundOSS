--
function setup()
	FONT_load("AlexBrush","asset://AlexBrush-Regular-OTF.otf")
end

function execute(deltaT)
	sysLoad("asset://List.lua")
end

function leave()
end
