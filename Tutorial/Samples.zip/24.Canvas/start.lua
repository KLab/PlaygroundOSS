function setup()
end

function execute(deltaT)
	sysLoad("asset://Canvas.lua")
end

function leave()

end
