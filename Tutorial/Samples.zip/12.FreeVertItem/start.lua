function setup()
end

function execute(deltaT)
	sysLoad("asset://FreeVertItem.lua")
end

function leave()

end
