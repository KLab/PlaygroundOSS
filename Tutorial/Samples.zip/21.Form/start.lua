function setup()
	FONT_load("Georgia","asset://AlexBrush-Regular-OTF.otf")
end

function execute(deltaT)
	sysLoad("asset://Form.lua")
end

function leave()

end
