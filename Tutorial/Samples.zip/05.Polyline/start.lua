function setup()
end

function execute(deltaT)
	sysLoad("asset://Polyline.lua")
end

function leave()

end
