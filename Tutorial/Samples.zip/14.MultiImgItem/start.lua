function setup()
end

function execute(deltaT)
	sysLoad("asset://MultiImgItem.lua")
end

function leave()

end
