function setup()
end

function execute(deltaT)
	sysLoad("asset://Score.lua")
end

function leave()

end
