function setup()
end

function execute(deltaT)
	sysLoad("asset://Scale9.lua")
end

function leave()

end
