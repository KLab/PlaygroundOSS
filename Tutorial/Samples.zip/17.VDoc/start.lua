function setup()
	FONT_load("Georgia","asset://AlexBrush-Regular-OTF.otf")
	GL_SetResolution(960, 640)
end

function execute(deltaT)
	sysLoad("asset://VDoc.lua")
end

function leave()

end
