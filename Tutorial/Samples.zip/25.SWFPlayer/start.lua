function setup()
end

function execute(deltaT)
	sysLoad("asset://SWFPlayer.lua")
end

function leave()

end
