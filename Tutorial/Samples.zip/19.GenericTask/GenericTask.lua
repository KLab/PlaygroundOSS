include("asset://genChar2.lua")

function setup()
	initChar2("task4", 100, -100, "asset://itemimage.png.imag")
	initChar2("task5", 300,    0, "asset://itemimage.png.imag")
	initChar2("task6", 500,  100, "asset://itemimage.png.imag")
end

function execute(deltaT)

end


function leave()
end
