function setup()
end

function execute(deltaT)
	sysLoad("asset://GenericTask.lua")
end

function leave()

end
