This is the detailed document for :
- LUA global functions & constants.
- Tasks construction & commands

The documentation is only available in japanese for now.

IMPORTANT NOTE :
As it was backed up from Trac Wiki, the link are not functionning
as the original Wiki is private.
We just did a backup to make sure that at
least people will have a default documentation available.
